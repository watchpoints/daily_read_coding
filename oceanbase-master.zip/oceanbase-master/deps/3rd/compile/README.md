We use a symlink to trick gcc into using ld.lld as the default linker since gcc does not support the '-fuse-ld' option.
